-- ---------------------   < aula1exer2 >   ---------------------
--
--                     SCRIPT APAGA (DDL)  
--
-- Data Criacao ...........: 20/10/2024
-- Autor(es) ..............: Carlos Eduardo Rodrigues
-- 
-- Banco de Dados .........: MySQL 8.0.36
-- Banco de Dados(nome) ...: aula1exer2
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- -----------------------------------------------------------------

USE aula1exer2;

DROP TABLE contem;
DROP TABLE telefone;
DROP TABLE PRODUTOS;
DROP TABLE VENDA;
DROP TABLE AREA;
DROP TABLE GERENTE;
DROP TABLE EMPREGADO;
DROP TABLE PESSOA;